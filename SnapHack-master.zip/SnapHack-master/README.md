# SKAR HACK

#SnapHck

اداة اختراق حسابات snapchat

تم برمجتها بواسطة احمد السامرائي


اسمي /احمد
 
 من العراق
 
   للتواصل معي على تلكرام 
   
   معرفي 
   
   @skar44
   
   اشترك في قناتنا لكي تنضم لنا
   
   https://www.youtube.com/channel/UC9HW3go2iW6T2sCbrh7bhew?view_as=subscriber
   
   
   #إخلاء المسؤولية القانونية
 #  Images 
 
![Screenshot at 2019-09-07 15-46-15](https://user-images.githubusercontent.com/54996997/64491066-d036e600-d231-11e9-8c7f-61a12c35f43a.png)


#الاوامر لتشغيل الاداة

#sudo apt-get install git

git clone https://github.com/skar44/SnapHack


#sudo apt-get update

#sudo apt-get install tor

#sudo apt-get install all

#sudo apt-get install python

#sudo apt-get install python2

#chmod +x SnapHack.sh

#sudo bash SnapHack.sh
