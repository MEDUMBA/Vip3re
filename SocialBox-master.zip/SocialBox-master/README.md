# SocialBox
SocialBox is a Bruteforce Attack Framework [ Facebook , Gmail , Instagram ,Twitter ] , Coded By Belahsan Ouerghi
# Installation
```
sudo apt-get install git
git clone https://github.com/TunisianEagles/SocialBox.git
cd SocialBox
chmod +x SocialBox.sh
chmod +x install-sb.sh
./install-sb.sh
./SocialBox.sh
```
# Screenshots :
![Test Image 8](https://raw.githubusercontent.com/TunisianEagles/SocialBox/master/Screenshots/sb.png)
# Tested On :
* Backbox linux
* Ubuntu 
* Kali linux
# Contact
* [Contact](https://www.facebook.com/ouerghi.belahsan) - Belahsan Ouerghi
# Authors :
* facebook  : Imad
* gmail     : Ha3MrX
* instagram : thelinuxchoice
* Twitter   : thelinuxchoice
* SocialBox : Belahsan Ouerghi
